package com.example.recordstarttime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordStartTimeApplicationTests {

    @Test
    void contextLoads() {
    }

}
