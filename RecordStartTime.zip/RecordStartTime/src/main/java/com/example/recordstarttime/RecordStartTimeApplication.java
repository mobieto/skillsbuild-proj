package com.example.recordstarttime;

import com.example.recordstarttime.model.CourseSession;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecordStartTimeApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(RecordStartTimeApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Initialize and demonstrate a course session
        CourseSession courseSession = new CourseSession();
        courseSession.start();
        System.out.println("Course started. Elapsed time: " + courseSession.getElapsedTime());

        // Simulate pausing and resuming
        courseSession.pause();
        System.out.println("Course paused. Elapsed time: " + courseSession.getElapsedTime());

        // Simulate resuming
        courseSession.resume();
        System.out.println("Course resumed. Elapsed time: " + courseSession.getElapsedTime());
    }
}
